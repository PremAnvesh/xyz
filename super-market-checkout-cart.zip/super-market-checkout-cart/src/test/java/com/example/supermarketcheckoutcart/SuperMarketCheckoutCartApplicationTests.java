package com.example.supermarketcheckoutcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperMarketCheckoutCartApplicationTests {

    @Test
    void contextLoads() {
    }

}

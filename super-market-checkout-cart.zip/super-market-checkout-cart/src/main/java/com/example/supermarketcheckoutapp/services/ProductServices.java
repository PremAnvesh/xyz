package com.example.supermarketcheckoutapp.services;

import com.example.supermarketcheckoutapp.domains.Product;
import com.example.supermarketcheckoutapp.repositories.ProductRepository;
import com.example.supermarketcheckoutapp.util.Error;
import com.example.supermarketcheckoutapp.util.SuperMarketCheckoutException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductServices {
    private final ProductRepository productRepository;

    public void postProduct(Product product) throws SuperMarketCheckoutException {
        try {
            productRepository.save(product);
        } catch (Exception e) {
            throw new SuperMarketCheckoutException(Error.INTERNAL_SERVER_ERROR, "Error while entering the record");
        }

    }

    public Product getProductsByID(String prodId) throws SuperMarketCheckoutException {
        Optional<Product> product = productRepository.findById(prodId);
        try {
            if (product.isEmpty()) {
                throw new SuperMarketCheckoutException(Error.NOT_FOUND, "Product Not Found");
            }
            return product.get();
        } catch (Exception e) {
            throw new SuperMarketCheckoutException(Error.INTERNAL_SERVER_ERROR, "Error while fetching Product");
        }

    }

    public List<Product> getAllProducts(int pageIndex, int pageSize, String sortDirection, String criteriaName, String categoryName, String searchQuery) throws SuperMarketCheckoutException {
        List<Product> products = productRepository.findAll();
        int len = Math.min(products.size(), pageSize);
        Pageable pageable;
        if (Objects.equals(sortDirection, "none")) {
            pageable = PageRequest.of(pageIndex, len);
        } else {
            if (sortDirection.equals("asc"))
                pageable = PageRequest.of(pageIndex, len, Sort.by(Sort.Direction.ASC, criteriaName));
            else
                pageable = PageRequest.of(pageIndex, len, Sort.by(Sort.Direction.DESC, criteriaName));
        }
        return searchProducts(categoryName, searchQuery, pageable);
    }

    private List<Product> searchProducts(String categoryName, String searchQuery, Pageable pageable) {
        if (categoryName.isEmpty() && !searchQuery.isEmpty()) {
            System.out.println("first check");
            return productRepository.findOnlyBySearchfields(searchQuery, pageable);
        } else if (searchQuery.isEmpty() && !categoryName.isEmpty()) {
            System.out.println("second check");
            return productRepository.findOnlyByCategoryfields(categoryName, pageable);
        } else if (!searchQuery.isEmpty()) {
            System.out.println("third check");
            return productRepository.findByfields(categoryName, searchQuery, pageable);
        } else
            return productRepository.findAll(pageable).getContent();
    }

    public void deleteProductsByID(String prodId) throws SuperMarketCheckoutException {
        try {
            productRepository.deleteById(prodId);
        } catch (Exception e) {
            throw new SuperMarketCheckoutException(Error.INTERNAL_SERVER_ERROR, "Error while Deleting the product");
        }

    }

    public void updateProductsByID(String prodId, Product prod) throws SuperMarketCheckoutException {
        try {
            Optional<Product> product = productRepository.findById(prodId);
            if (product.isEmpty()) {
                System.out.println("Not found");
                throw new SuperMarketCheckoutException(Error.NOT_FOUND, "Product Not Found");
            }
            productRepository.save(prod);
        } catch (Exception e) {
            throw new SuperMarketCheckoutException(Error.INTERNAL_SERVER_ERROR, "Error while updating Product");
        }


    }
}

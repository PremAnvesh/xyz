package com.example.supermarketcheckoutapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperMarketCheckoutAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(SuperMarketCheckoutAppApplication.class, args);
    }
}

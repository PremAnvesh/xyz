package com.example.supermarketcheckoutapp.util;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public enum ResponseStatus {


    INTERNAL_SERVER_ERROR(500){
        @Override
        public HttpStatus getHttpStatus(){
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    },  VALIDATION_ERROR(400){
        @Override
        public HttpStatus getHttpStatus(){
            return HttpStatus.BAD_REQUEST;
        }
    },   NOT_FOUND(404){
        @Override
        public HttpStatus getHttpStatus(){
            return HttpStatus.NOT_FOUND;
        }
    }, BAD_REQUEST(400){
        @Override
        public HttpStatus getHttpStatus(){
            return HttpStatus.BAD_REQUEST;
        }
    };

    private int code;

    public abstract HttpStatus getHttpStatus();

    ResponseStatus(int code){
        this.code = code;
    }


}

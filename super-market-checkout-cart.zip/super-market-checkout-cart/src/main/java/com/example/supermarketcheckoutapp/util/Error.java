package com.example.supermarketcheckoutapp.util;

import lombok.Getter;

@Getter
public enum Error {
    INTERNAL_SERVER_ERROR(500,"Internal Server Error"),
    VALIDATION_ERROR(400,"Validation Error"),
    BAD_REQUEST(400,"Bad Request"),
    NOT_FOUND(404,"Not Found"),
    UNAUTHORIZED(401,"Unauthorized"),
    USER_ALREADY_EXISTS(422,"User Already Exists");

    private int code;
    private String message;

    Error(int code, String message) {
        this.code = code;
        this.message = message;
    }
}

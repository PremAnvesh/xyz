package com.example.supermarketcheckoutapp.util;

import lombok.Getter;

@Getter
public class SuperMarketCheckoutException extends Exception{
   private Error error;
   private String msg;
   public SuperMarketCheckoutException(){

   }
   public SuperMarketCheckoutException(Error error, String msg){
       super();
       this.error = error;
       this.msg = msg;
   }
}
